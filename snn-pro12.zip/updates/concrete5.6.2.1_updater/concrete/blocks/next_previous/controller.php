<?php   defined('C5_EXECUTE') or die("Access Denied."); 

class NextPreviousBlockController extends Concrete5_Controller_Block_NextPrevious { 


}