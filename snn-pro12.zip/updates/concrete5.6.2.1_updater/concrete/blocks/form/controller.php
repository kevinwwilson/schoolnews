<?php  
defined('C5_EXECUTE') or die("Access Denied.");
class FormBlockController extends Concrete5_Controller_Block_Form {}
class FormBlockStatistics extends Concrete5_Controller_Block_FormStatistics {}
class MiniSurvey extends Concrete5_Controller_Block_FormMinisurvey {}