<?php 
defined('C5_EXECUTE') or die("Access Denied.");
Loader::controller('/profile/edit');

class ProfileAvatarController extends Concrete5_Controller_Profile_Avatar {
	


}